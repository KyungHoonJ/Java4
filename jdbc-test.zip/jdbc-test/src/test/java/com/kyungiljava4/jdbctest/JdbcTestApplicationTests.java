package com.kyungiljava4.jdbctest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
