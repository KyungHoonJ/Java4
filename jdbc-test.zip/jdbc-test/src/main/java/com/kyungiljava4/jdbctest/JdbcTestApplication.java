package com.kyungiljava4.jdbctest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcTestApplication.class, args);
	}

}
